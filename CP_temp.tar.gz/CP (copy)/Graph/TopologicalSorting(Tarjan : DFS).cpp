#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vC vector<char>
#define vlD vector<lD>
#define vvC vector<vC>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LONG_MIN
#define INF LONG_MAX

//'n' tasks and 'm' relations between the tasks
//Printing 1 solution of topological sorting
//if want all solution to be printed : remove line 39
vB seen(101);
vvl edge(101);
vl indeg(101);
int anslen,n,m;
vl ans;
bool printed;
void dfs(){
  if(printed) return;
  if(ans.size()==anslen){
    printed=true;
    for(int i=0;i<anslen;i++){
      cout<<ans[i];
      if(i!=anslen-1) cout<<" ";
    }
    cout<<"\n";
    return;
  }
  for(int i=1;i<=n;i++){
    if(!seen[i] && !indeg[i]){
      seen[i]=true;
      for(auto it:edge[i]){
        indeg[it]--;
      }
      ans.pb(i);
      dfs();
      seen[i]=false;
      for(auto it:edge[i]){
        indeg[it]++;
      }
      ans.pop_back();
    }
  }
}
int main(){
  fio;
  cin.tie(NULL);
  cin>>n>>m;
  while(n || m){
    printed=false;
    anslen=n;
    for(int i=1;i<=n;i++){
      seen[i]=false;
      edge[i].clear();
      indeg[i]=0;
    }
    for(int i=1;i<=m;i++){
      int t1,t2;
      cin>>t1>>t2;
      edge[t1].pb(t2);
      indeg[t2]++;
    }
    dfs();
    cin>>n>>m;
  }
  return 0;
}