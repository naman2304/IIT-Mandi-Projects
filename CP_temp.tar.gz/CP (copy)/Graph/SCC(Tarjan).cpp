#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define UNVISITED INT_MAX

vvl edge;
vl visited,num,low;
stack<int> S;
int ct,numSCC;

void tarjanSCC(int u){
  num[u]=low[u]=ct++;
  visited[u]=1;
  S.push(u);
  for(auto v:edge[u]){
    if(num[v]==UNVISITED)
      tarjanSCC(v);
    if(visited[v])
      low[u]=min(low[u],low[v]);
  }
  if(num[u]==low[u]){
    numSCC++;
    while(1){
      int v=S.top();
      S.pop();
      visited[v]=0;
      cout<<v<<" ";
      if(u==v) break;
    }
    cout<<"\n";
  }
}
int main(){
  fio;
  cin.tie(NULL);
  int t;
  cin>>t;
  while(t--){
    int n,m;
    cin>>n>>m;
    edge.clear();
    edge.resize(n);
    visited.assign(n,0);
    num.assign(n,UNVISITED);
    low.assign(n,0);
    ct=0;
    numSCC=0;
    for(int i=0;i<m;i++){
      int u,v;
      cin>>u>>v;
      edge[u-1].pb(v-1);
    }
    for(int i=0;i<n;i++){
      if(num[i]==UNVISITED){
        tarjanSCC(i);
      }
    }
  }
  return 0;
} 