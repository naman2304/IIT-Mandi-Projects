#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
#define INF LONG_MAX
#define NINF LONG_MIN
//cout<<"Case #"<<tc<<": ";
 
vvll edge;
int n,m;
vl dist;

// dist[x]=NINF denotes that path is not defined (due to -ve cycle encountered)
// dist[x]=INF  denotes that path deesn't exist
// else the answer is given
// O(VE)
void bellman_ford(int src){
  dist[src]=0;
  for(int k=0;k<n-1;k++){
    for(int i=0;i<n;i++){
      for(auto it:edge[i]){
        if(dist[i]<INF && dist[it.first]>dist[i]+it.second){
          dist[it.first]=dist[i]+it.second;
        }
      }
    }
  }
}
bool negative_cycle(){
  bool neg=false;
  for(int i=0;i<n;i++){
    for(auto it:edge[i]){
      if(dist[i]<INF && dist[it.first]>dist[i]+it.second){ 
        dist[it.first]=NINF; //Path undefined from node "src" to node "it.first"
        neg=true;
      }
    }
  }
  return neg;
}
int main(){
  fio;
  cin.tie(NULL);
  int t;
  cin>>t;
  while(t--){
    cin>>n>>m;
    dist.clear();
    dist.assign(n,INF);
    edge.clear();
    edge.resize(n);
    for(int i=0;i<m;i++){
      lli t1,t2,t3;
      cin>>t1>>t2>>t3;
      edge[t1].pb(mp(t2,t3));
    }
    bellman_ford(0);
    if(negative_cycle()) cout<<"possible\n";
    else cout<<"not possible\n";
  }
  return 0;
} 