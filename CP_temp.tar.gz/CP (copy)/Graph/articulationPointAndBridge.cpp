#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-8
#define INF INT_MAX
#define NINF LONG_MIN
#define UNVISITED INT_MAX
//cout<<"Case #"<<tc<<": ";

int n,m,ct,dfsroot,rootChildren;
vvl edge;
vl low,parent,art,num;
//0-based indexing
//Undirected graph only
void articulationPointAndBridge(int u){
  num[u]=low[u]=ct++;
  for(auto v:edge[u]){
    if(num[v]==UNVISITED){  //Tree edge
      parent[v]=u;
      if(u==dfsroot) rootChildren++; //special case: u is root
      articulationPointAndBridge(v);
      if(low[v]>=num[u]){
        art[u]++; //This may fire multiple times for a node. 
                     //No. of times fired=no. of components graph breaks into after removing this node
      }
      if(low[v]>num[u]){
        cout<<"Bridge found b/w "<<u<<" and "<<v<<"\n";
      }
      low[u]=min(low[u],low[v]);
    }else{                   //Back edge
      if(parent[u]!=v){     //Avoiding direct cycle
        low[u]=min(low[u],num[v]);
      }
    }
  }
}
int main(){
  fio;
  cin.tie(NULL);
  cin>>n>>m;
  edge.resize(n);
  parent.assign(n,-1);
  low.assign(n,-1);
  num.assign(n,UNVISITED);
  art.assign(n,0);
  ct=0;
  for(int i=0;i<m;i++){
    int a,b;
    cin>>a>>b;
    edge[a].pb(b);
    edge[b].pb(a);
  }
  cout<<"Bridges are : \n";
  for(int i=0;i<n;i++){
    if(num[i]==UNVISITED){
      dfsroot=i;
      rootChildren=0;
      articulationPointAndBridge(i);
      art[dfsroot]=(rootChildren>1)?rootChildren-1:0;
    }
  }
  // (art[i]+1) is the number of components graph breaks into if we remove vertex with id i
  cout<<"----------------\n";
  cout<<"Articulation Point are : \n";
  for(int i=0;i<n;i++) if(art[i]) cout<<i<<" ";
  cout<<"\n";
  return 0;
} 