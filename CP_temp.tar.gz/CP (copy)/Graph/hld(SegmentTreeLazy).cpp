#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF INT_MAX
#define NINF LONG_MIN
int N = 50200;
int LN = 20;
typedef struct mytype{
  int fst,lst,rem;
}mytype;
int chainNo,ptr=0;
vvll edge(N);
vl baseArray(N),chainHead(N),chainInd(N),subsize(N),seen(N),depth(N),posInBase(N),init(N);
vvl par(LN,vl(N));
mytype zz={INF,INF,INF};
vector<mytype> tree(N*4+5,zz);
vl lazy(N*4+5);

void dfs(int src,int cdepth){
  seen[src]=1;
  depth[src]=cdepth;
  subsize[src]=1;
  for(auto it:edge[src]){
    if(!seen[it.first]){
      dfs(it.first,cdepth+1);
      subsize[src]+=subsize[it.first];
      par[0][it.first]=src;
    }
  }
}

//Using concept of vertex disjoint paths and not edge disjoint paths
//Hence wt of node 0 is -1
//        X                       X(-1)
//    (3)/ \(7)                  / \
//      X   X        --->    (3)X   X(7)
//         / \(2)                  / \
//     (4)/   \                   /   \
//       X     X              (4)X     X(2)
void HLD(int src,int cst,int prev){
  if(chainHead[chainNo]==-1) chainHead[chainNo]=src;
  chainInd[src]=chainNo;
  posInBase[src]=ptr;
  baseArray[ptr]=cst;
  ptr++;
  int nsrc=-1;
  for(auto it:edge[src]){
    if(it.first!=prev){
      if(nsrc==-1 || subsize[nsrc]<subsize[it.first]){
        nsrc=it.first;
      }
    }
  }
  if(nsrc!=-1) HLD(nsrc,init[nsrc],src);
  for(auto it:edge[src]){
    if(it.first!=prev && it.first!=nsrc){
      chainNo++;
      HLD(it.first,init[it.first],src);
    }
  }
}

int lca(int u, int v){
  if(depth[u]<depth[v]) swap(u,v);
  int k=depth[u]-depth[v];
  for(int i=0;i<LN;i++) if((1<<i)&k) u=par[i][u];
  if(u==v) return u;
  for(int i=LN-1;i>=0;i--) if(par[i][u]!=par[i][v]) {
    u=par[i][u];
    v=par[i][v];
  }
  return par[0][u];
}

//i-indexed tree and 1 indexed A
class SegmentTree{
private:
  int n;
  int left (int p) { return p<<1; }
  int right(int p) { return (p<<1)+1; }

  mytype combine(mytype x,mytype y){
    if(x.fst==INF && x.lst==INF && x.rem==INF) return y;
    if(y.fst==INF && y.lst==INF && y.rem==INF) return x;
    mytype c;
    c.fst=x.fst;
    c.lst=y.lst;
    c.rem=__gcd(x.rem,__gcd(abs(y.fst-x.lst),y.rem));
    return c;
  }

  void build(int p,int l,int r){
    if(l>r) return;
    if(l==r){
      tree[p].fst=baseArray[l];
      tree[p].lst=baseArray[l];
      tree[p].rem=0;
    }else{
      build(left(p),l,(l+r)/2);
      build(right(p),(l+r)/2+1,r);
      tree[p]=combine(tree[left(p)],tree[right(p)]);
    }
  }

  mytype query(int p,int l,int r,int i,int j){
    if(lazy[p]!=0){
      tree[p].fst+=lazy[p];
      tree[p].lst+=lazy[p];
      if(l!=r){ //Not leaf
        lazy[left(p)]+=lazy[p];
        lazy[right(p)]+=lazy[p];
      }
      lazy[p]=0;
    }
    if(l>r || l>j || r<i){
      mytype zz={INF,INF,INF};
      return zz;
    }
    int mid=(l+r)/2;
    if(l>=i && r<=j) return tree[p];
    if(j<=mid) return query(left(p),l,mid,i,j);
    else if(i>mid) return query(right(p),mid+1,r,i,j);
    mytype x=query(left(p),l,mid,i,mid);
    mytype y=query(right(p),mid+1,r,mid+1,j);
    tree[p]=combine(tree[left(p)],tree[right(p)]);
    return combine(x,y);
  }
  
  void update(int p,int a,int b,int i,int j,int val){
    if(lazy[p]!=0){
      tree[p].fst+=lazy[p];
      tree[p].lst+=lazy[p];
      if(a!=b){ //Not leaf
        lazy[left(p)]+=lazy[p];
        lazy[right(p)]+=lazy[p];
      }
      lazy[p]=0;
    }
    if(a>b || a>j || b<i) return;
    if(a>=i && b<=j){
      tree[p].fst+=val;
      tree[p].lst+=val;
      if(a!=b){
        lazy[left(p)]+=val;
        lazy[right(p)]+=val;
      }
      return;
    }
    int mid=(a+b)/2;
    update(left(p),a,mid,i,j,val);
    update(right(p),mid+1,b,i,j,val);
    tree[p]=combine(tree[left(p)],tree[right(p)]);
  }
public:
  SegmentTree(const vl &_A){
    n=(int)_A.size()-1;
    build(1,1,n);
  }

  int query(int i,int j){
    mytype anss=query(1,1,n,i,j);
    return __gcd(anss.fst,anss.rem);
  }

  void update(int a,int b,int val){
    update(1,1,n,a,b,val);
  }
};

SegmentTree *S;

int query_up(int u,int v){
  int uchain,vchain=chainInd[v],ans=0;
  while(1){
    uchain=chainInd[u];
    if(uchain==vchain){
      ans=__gcd(ans,(int)S->query(posInBase[v],posInBase[u]));
      break;
    }
    ans=__gcd(ans,(int)S->query(posInBase[chainHead[uchain]],posInBase[u]));
    u=chainHead[uchain];
    u=par[0][u];
  }
  return ans;
}

int query(int u,int v){
  int w=lca(u,v);
  int t1=query_up(u,w);
  int t2=query_up(v,w);
  return __gcd(t1,t2);
}

// Walk up to kth ancestor of u and return the kth ancestor
int walk(int u,int k){
  for(int i=0;i<LN;i++) if((1<<i)&k) u=par[i][u];
    return u;
}

int dist(int u,int v){
  int w=lca(u,v);
  return depth[u]+depth[v]-2*depth[w];
}

void change_up(int u,int v,int delta){
  int uchain,vchain=chainInd[v];
  while(1){
    uchain=chainInd[u];
    if(uchain==vchain){
      S->update(posInBase[v],posInBase[u],delta);
      break;
    }
    S->update(posInBase[chainHead[uchain]],posInBase[u],delta);
    u=chainHead[uchain];
    u=par[0][u];
  }
}

void change(int u,int v,int c){
  int w=lca(u,v);
  if(u==v){
    change_up(u,v,c);
  }else if(w==u){
    change_up(v,u,c);
  }else if(w==v){
    change_up(u,v,c);
  }else{
    change_up(u,w,c);
    int dd=dist(v,w);
    --dd;
    int x=walk(v,dd);
    change_up(v,x,c);
  }
}

int main(){
  fio;
  cin.tie(NULL);
  int n;
  cin>>n;
  for(int i=0;i<n;i++){
    edge[i].clear();
    chainHead[i]=-1;
    seen[i]=0;
    depth[i]=0;
    init[i]=0;
    for(int j=0;j<LN;j++) par[j][i]=-1;
  }
  for(int i=1;i<n;i++){
    int u,v;
    cin>>u>>v;
    edge[u].pb(mp(v,1));
    edge[v].pb(mp(u,1));
  }
  for(int i=0;i<n;i++){
    cin>>init[i];
  }
  ptr=1;
  chainNo=0;
  dfs(0,0);
  HLD(0,init[0],-1);
  S=new SegmentTree(baseArray);
  for(int k=1;k<LN;k++){
    for(int i=0;i<n;i++){
      if(par[k-1][i]==-1) continue;
      par[k][i]=par[k-1][par[k-1][i]];
    }
  }
  int q;
  cin>>q;
  for(int i=0;i<q;i++){
    char ch;
    cin>>ch;
    if(ch=='F'){
      int a,b;
      cin>>a>>b;
      cout<<query(a,b)<<"\n";
    }else{
      int a,b,c;
      cin>>a>>b>>c;
      change(a,b,c);
    }
  }
  return 0;
} 