#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vC vector<char>
#define vlD vector<lD>
#define vvC vector<vC>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LONG_MIN
#define INF LONG_MAX


/*
Input : 
8
a
b
c
d
e
f
s
t
6
a e
a b
c d
e f
s t
a t

8
s
a
b
e
f
c
d
t
6
a e
a b
c d
e f
s t
a t

8
a
b
c
s
t
e
f
d
6
a b
a e
c d
e f
s t
a t
*/
//Kahn's Algorithm for topological sortin
//Lexicographically smallest topological sort
//If there is no relation between two tasks 
//then the one appearing first(in 'n' list)(not in 'm' list) should come first
int n,m;
vB seen;
vvl edge;
vl ans,indeg;
map<string,int> mp;
map<int,string> mp2;

int main(){
  fio;
  cin.tie(NULL);
  int tc=1;
  while(cin>>n){
    ans.clear();
    indeg.clear();
    mp.clear();
    mp2.clear();
    seen.clear();
    edge.clear();
    seen.assign(n+1,false);
    indeg.assign(n+1,false);
    ans.assign(n+1,0);
    edge.resize(n+1);
    for(int i=1;i<=n;i++){
        string s;
        cin>>s;
        mp[s]=i;
        mp2[i]=s;
    }
    cin>>m;
    for(int i=1;i<=m;i++){
        string s1,s2;
        cin>>s1>>s2;
        edge[mp[s1]].pb(mp[s2]);
        indeg[mp[s2]]++;
    }
    priority_queue<int,vi,greater<int> > q; //min heap
    int ind=1;
    for(int i=1;i<=n;i++){
        if(indeg[i]==0){
            q.push(i);
            seen[i]=true;
        }
    }
    while(!q.empty()){
        int temp=q.top();
        q.pop();
        ans[ind]=temp;
        ind++;
        for(auto it:edge[temp]) indeg[it]--;
        for(auto it:edge[temp]){
            if(!seen[it] && indeg[it]==0){
                q.push(it);
                seen[it]=true;
            }
        }
    }
    cout<<"Case #"<<tc<<":\n";
    for(int i=1;i<=n;i++){
        cout<<mp2[ans[i]]<<" ";
    }
    cout<<"\n\n";
    tc++;
  }
  return 0;
}