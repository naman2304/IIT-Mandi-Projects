#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
#define INF LONG_MAX
#define NINF LONG_MIN
#define VMAX 102
//cout<<"Case #"<<tc<<": ";

int n,src,snk,m;
vvl res;
vl parent;
vB seen;

// Edmond Karp
// O(V^3 E), if used some clever adjacency list representation, then O(V E^2).
lli augment(lli u,lli minEdge){
  if(u==src){
    return minEdge;
  }
  lli ans=augment(parent[u],min(minEdge,res[parent[u]][u]));
  res[parent[u]][u]-=ans;
  res[u][parent[u]]+=ans;
  return ans;
}
lli max_flow(){
  lli mf=0;
  while(1){
    bool path=false;
    parent.assign(n+1,-1);
    seen.assign(n+1,false);
    queue<lli> q;
    q.push(src);
    while(!q.empty()){
      lli u=q.front();
      q.pop();
      if(u==snk){
        path=true;
        break;
      }
      for(int v=1;v<=n;v++){
        if(!seen[v] && res[u][v]>0){
          seen[v]=true;
          q.push(v);
          parent[v]=u;
        }
      }
    }
    if(!path) break;
    lli f=augment(snk,INF);
    mf+=f;
  }
  return mf;
}

int main(){
  fio;
  cin.tie(NULL);
  int tc=1;
  cin>>n;
  while(n){
    res.clear();
    res.resize(n+1);
    for(int i=0;i<=n;i++) res[i].assign(n+1,0);
    cin>>src>>snk>>m;
    for(int i=0;i<m;i++){
      int u,v,wt;
      cin>>u>>v>>wt;
      res[u][v]+=wt;
      res[v][u]+=wt; //given in Q : bidirectional edges
    }
    cout<<"Network "<<tc<<"\n";
    cout<<"The bandwidth is ";
    cout<<max_flow()<<".\n\n";
    cin>>n;
    tc++;
  }
  return 0;
} 