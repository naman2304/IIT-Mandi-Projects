#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>jjkklliii
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define UNVISITED INT_MAX

lli n,q,ct,ans;
vvl edge;
vl depth,nodepos,rnodepos,A;

void swap(int &a,int &b){
  int t=a;
  a=b;
  b=t;
}

void dfs(int src,int currdepth){
  depth[src]=currdepth;
  nodepos[src]=ct;
  rnodepos[ct]=src;
  A[ct++]=currdepth;
  for(auto it:edge[src]){
    dfs(it,currdepth+1);
    rnodepos[ct]=src;
    A[ct++]=currdepth;
  }

}

// Static data structure 
// 0-indexed array
class SparseTable{
  vvl table,idx;
  int maxk,n;
  public:
    int findsz(int n){
      int ans=0,curr=1;
      while((curr<<1)<=n){
        curr=curr<<1;
        ans++;
      }
      return ans;
    }
    SparseTable(){

    }
    SparseTable(vl &arr){
      n=arr.size();
      maxk=findsz(n);
      table.resize(maxk+1);
      idx.resize(maxk+1);
      for(int i=0;i<=maxk;i++){
        table[i].resize(n);
        idx[i].resize(n);
      }
      for(int i=0;i<n;i++){
        table[0][i]=arr[i];
        idx[0][i]=i;
      }
      for(int k=1;k<=maxk;k++){
        for(int i=0;i<n;i++){
           int j=i+(1<<(k-1));
           if(j<n){
            if(table[k-1][i]<table[k-1][j]){
              idx[k][i]=idx[k-1][i];
              table[k][i]=table[k-1][i];
            }else{
              idx[k][i]=idx[k-1][j];
              table[k][i]=table[k-1][j];
            }
           }
        }
      }
    }
    int minimum(int a,int b){
      int len=b-a+1;
      int k=findsz(len);
      int m=b-(1<<k)+1;
      //return min(table[k][a],table[k][m]);
      if(table[k][a]<table[k][m])
        return idx[k][a];
      return idx[k][m];
    }
};

SparseTable *S;

int lca(int a,int b){
  int x=nodepos[a];
  int y=nodepos[b];
  if(x>y) swap(x,y);
  int pos=S->minimum(x,y);
  return rnodepos[pos];
}

int dis(int u,int v){
  lli w = lca(u,v);
  return depth[u]+depth[v]-2*depth[w];
}

int main(){
  fio;
  cin.tie(NULL);
  cin>>n>>q;
  ct=0;
  edge.resize(n);
  depth.resize(n);
  nodepos.resize(n);
  A.resize(2*n-1);
  rnodepos.resize(2*n-1);
  for(int i=2;i<=n;i++){
    int tmp;
    cin>>tmp;
    edge[tmp-1].pb(i-1);
  }
  dfs(0,0);
  S=new SparseTable(A);
  for(int i=0;i<q;i++){
    lli a,b;
    cin>>a>>b;
    --a; --b;
    cout<<lca(a,b)+1<<"\n";
  }
  return 0;
} 