#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
#define NINF LONG_MIN
//cout<<"Case #"<<tc<<": ";
 
void dijkstra(vvll &edge,lli src,vl &dist){
  dist[src]=0;
  set<ll> myst;
  myst.insert(mp(0,src));
  while(!myst.empty()){
    ll temp=*myst.begin();
    myst.erase(temp);
    for(auto it:edge[temp.second]){
      if(dist[it.first]>dist[temp.second]+it.second){
        if(dist[it.first]!=std::numeric_limits<lli>::max())
          myst.erase(myst.find(mp(dist[it.first],it.first)));
        dist[it.first]=dist[temp.second]+it.second;
        myst.insert(mp(dist[it.first],it.first));
      }
    }
  }
}
int main(){
  lli n,x,y;
  cin>>n>>x>>y;
  vvll edge(2*n+5);
  edge[0].pb(mp(1,x));
  for(lli i=2;i<=2*n;i++){
    edge[i].pb(mp(i+1,x));
    edge[i+1].pb(mp(i,x));
  }
  edge[1].pb(mp(2,min(x,y)));
  edge[2].pb(mp(1,x));
  lli ind=2;
  while(ind<=n){
    edge[ind].pb(mp(2*ind,y));
    ind++;
  }
  vl dist(2*n+5,std::numeric_limits<lli>::max());
  dijkstra(edge,0,dist);
  cout<<dist[n];
  return 0;
} 