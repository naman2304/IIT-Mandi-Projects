#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
lli n;
typedef struct Point{
	double x,y;
}Point;
vector<Point> pt(MAX);
vector<Point> X(MAX);
vector<Point> Y(MAX);
bool compX(const Point &p1,const Point &p2){
	return (p1.x-p2.x)<EPS;
}
bool compY(const Point &p1,const Point &p2){
	return (p1.y-p2.y)<EPS;
}
double dist(Point &p1,Point &p2){
	return (double)sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}
double brute(lli low,lli high){
	double ans=DBL_MAX;
	for(int i=low;i<high;i++){
		for(int j=i+1;j<=high;j++){
			ans=min(ans,dist(pt[i],pt[j]));
		}
	}
	return ans;
}
double stripclosest(vector<Point> &strip,double del){
	double ans=del;
	for(int i=0;i<strip.size();i++){
		for(int j=i+1;j<strip.size() && strip[j].y-strip[i].y<ans+EPS;j++){
			if(dist(strip[j],strip[i])<ans){
				ans=dist(strip[j],strip[i]);
			}
		}
	}
	return ans;
}
double closestPair(lli low,lli high){
	if(high<=low) return DBL_MAX;
	else if(high-low<=2) return brute(low,high);
	lli mid=(low+high)/2;
	Point midpt=X[mid];
	Point temp;
	double dL=closestPair(low,mid);
	double dR=closestPair(mid+1,high);
	double del=min(dL,dR);
	vector<Point> strip;
	for(int i=0;i<n;i++){
		if(fabs(Y[i].x-midpt.x)<del+EPS){
			temp.x=Y[i].x;
			temp.y=Y[i].y;
			strip.pb(temp);
		}
	}
	double stripmin=stripclosest(strip,del);
	return min(del,stripmin);
}
int main(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>pt[i].x>>pt[i].y;
		X[i].x=Y[i].x=pt[i].x;
		X[i].y=Y[i].y=pt[i].y;
	}
	sort(X.begin(),X.begin()+n,compX);
	sort(Y.begin(),Y.begin()+n,compY);
	cout<<fixed<<setprecision(10)<<closestPair(0,n-1);
	return 0;
}