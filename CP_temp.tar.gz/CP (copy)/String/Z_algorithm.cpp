#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LONG_MIN
#define INF LONG_MAX

vi calcZ(vi &A){
  int left=0,right=0;
  vi Z(A.size());
  Z[0]=0;
  for(int i=1;i<A.size();i++){
    if(i>right){
      left=right=i;
      while(right<A.size() && A[right-left]==A[right]){
        right++;
      }
      Z[i]=right-left;
      --right;
    }else{
      int k=i-left;
      if(Z[k]<right-i+1){
        Z[i]=Z[k];
      }else{
        left=i;
        while(right<A.size() && A[right-left]==A[right]){
          right++;
        }
        Z[i]=right-left;
        --right;
      }
    }
  }
  return Z;
}

int search(vi &pattern,vi &text){
  vi arr(pattern.begin(),pattern.end());
  arr.push_back(INT_MAX);
  arr.insert(arr.end(),text.begin(),text.end());
  vi Zarr=calcZ(arr);
  int ans=0;
  for(int i=0;i<Zarr.size();i++){
    if(Zarr[i]==pattern.size()) ans++;
  }
  return ans;
}
int main(){
  fio;
  cin.tie(NULL);
  int n,m;
  cin>>n>>m;
  vi A(n),B(m);
  for(int i=0;i<n;i++) cin>>A[i];
  for(int i=0;i<m;i++) cin>>B[i];
  cout<<search(B,A);
  return 0;
}