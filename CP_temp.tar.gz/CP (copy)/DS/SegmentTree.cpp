#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vC vector<char>
#define vlD vector<lD>
#define vvC vector<vC>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LLONG_MIN
#define INF LLONG_MAX  

//i-indexed tree and 1 indexed A
class SegmentTree{
private:
  vl tree,A;
  map<lli,lli> mp;
  lli n;
  lli left (lli p) { return p<<1; }
  lli right(lli p) { return (p<<1)+1; }

  lli combine(lli x,lli y){
    return min(x,y);
  }

  void build(lli p,lli l,lli r){
    if(l==r){
      tree[p]=A[l];
      mp[l]=p;
    }else{
      build(left(p),l,(l+r)/2);
      build(right(p),(l+r)/2+1,r);
      tree[p]=combine(tree[left(p)],tree[right(p)]);
    }
  }

  lli query(lli p,lli l,lli r,lli i,lli j){
    if(i>r || j<l) return INF;
    lli mid=(l+r)/2;
    if(l>=i && r<=j) return tree[p];
    if(j<=mid) return query(left(p),l,mid,i,j);
    else if(i>mid) return query(right(p),mid+1,r,i,j);
    lli x=query(left(p),l,mid,i,mid);
    lli y=query(right(p),mid+1,r,mid+1,j);
    return combine(x,y);
  }
  
public:
  SegmentTree(const vl &_A){
    A=_A;
    n=(lli)A.size()-1;
    tree.assign(4*n+5,0);
    build(1,1,n);
  }

  lli query(lli i,lli j){
    return query(1,1,n,i,j);
  }

  void update(lli pos,lli val){
    pos=mp[pos];
    tree[pos]=val;
    int fat=pos/2;
    while(fat!=0){
        tree[fat]=combine(tree[left(fat)],tree[right(fat)]);
        fat=fat/2;
    }
  }
};
int main(){
  int n;
  cin>>n;
  vl A(n+1);
  for(int i=1;i<=n;i++) cin>>A[i];
  SegmentTree S(A);
  cout<<S.query(3,4)<<"\n";
  return 0;
}