#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vC vector<char>
#define vlD vector<lD>
#define vvC vector<vC>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LLONG_MIN
#define INF LLONG_MAX  

//i-indexed tree and 1 indexed A
class SegmentTree{
private:
  vl tree,A,lazy;
  lli n;
  lli left (lli p) { return p<<1; }
  lli right(lli p) { return (p<<1)+1; }

  lli combine(lli x,lli y){
    return min(x,y);
  }

  void build(lli p,lli l,lli r){
    if(l>r) return;
    if(l==r){
      tree[p]=A[l];
    }else{
      build(left(p),l,(l+r)/2);
      build(right(p),(l+r)/2+1,r);
      tree[p]=combine(tree[left(p)],tree[right(p)]);
    }
  }

  lli query(lli p,lli l,lli r,lli i,lli j){
    if(lazy[p]!=NINF){
      tree[p]=lazy[p];
      if(l!=r){ //Not leaf
        lazy[left(p)]=lazy[p];
        lazy[right(p)]=lazy[p];
      }
      lazy[p]=NINF;
    }
    if(l>r || l>j || r<i) return INF;
    lli mid=(l+r)/2;
    if(l>=i && r<=j) return tree[p];
    if(j<=mid) return query(left(p),l,mid,i,j);
    else if(i>mid) return query(right(p),mid+1,r,i,j);
    lli x=query(left(p),l,mid,i,mid);
    lli y=query(right(p),mid+1,r,mid+1,j);
    tree[p]=combine(tree[left(p)],tree[right(p)]);
    return combine(x,y);
  }
  
  void update(lli p,lli a,lli b,lli i,lli j,lli val){
    if(lazy[p]!=NINF){
      tree[p]=lazy[p];
      if(a!=b){ //Not leaf
        lazy[left(p)]=lazy[p];
        lazy[right(p)]=lazy[p];
      }
      lazy[p]=NINF;
    }
    if(a>b || a>j || b<i) return;
    if(a>=i && b<=j){
      tree[p]=val;
      if(a!=b){
        lazy[left(p)]=val;
        lazy[right(p)]=val;
      }
      return;
    }
    int mid=(a+b)/2;
    update(left(p),a,mid,i,j,val);
    update(right(p),mid+1,b,i,j,val);
    tree[p]=combine(tree[left(p)],tree[right(p)]);
  }
public:
  SegmentTree(const vl &_A){
    A=_A;
    n=(lli)A.size()-1;
    tree.assign(4*n+5,0);
    lazy.assign(4*n+5,NINF);  //NINF indicates that this node is "good"
    build(1,1,n);
  }

  lli query(lli i,lli j){
    return query(1,1,n,i,j);
  }

  void update(lli a,lli b,lli val){
    update(1,1,n,a,b,val);
  }
};
int main(){
  int t;
  cin>>t;
  while(t--){
    int n,q;
    cin>>n>>q;
    vl A(n+1);
    for(int i=1;i<=n;i++){
      cin>>A[i];
    }
    SegmentTree S(A);
    for(int i=0;i<q;i++){
      int ch;
      cin>>ch;
      if(ch==0){
        int a,b;
        cin>>a>>b;
        cout<<S.query(a,b)<<"\n";
      }else{
        int a,b,c;
        cin>>a>>b>>c;
        S.update(a,b,c);
      }
    }
  }
  return 0;
}