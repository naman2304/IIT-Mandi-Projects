#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
#define NINF LONG_MIN
#define INF LONG_MAX
//cout<<"Case #"<<tc<<": ";

int main(){
    lli t,tc=1;
    cin>>t;
    while(t--){
        lli n;
        cin>>n;
        vl A(n+1);
        vl dp(n+1,1);
        for(int i=1;i<=n;i++){
            cin>>A[i];
        }
        for(int i=2;i<=n;i++){
            lli ans=0;
            for(int j=i-1;j>=1;j--){
                if(A[j]<A[i]){
                    dp[i]=max(dp[i],dp[j]+1);
                }
            }
        }
        lli fans=NINF;
        for(int i=1;i<=n;i++){
            fans=max(fans,dp[i]);
        }
        cout<<fans<<"\n";
    }
    return 0;
}