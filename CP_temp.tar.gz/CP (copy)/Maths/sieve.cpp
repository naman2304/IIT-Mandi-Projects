#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define SMAX 50000

//Goldman's Conjecture
//Every even integer greater than 2 can be expressed as the sum of two primes.

vB prime(SMAX,true);
vl primes,segprimes;
vB segprime;
void sieve(){
  prime[0]=prime[1]=false;
  for(int i=2;i*i<SMAX;i++){
    if(prime[i]){
      for(int j=i*i;j<SMAX;j+=i){
        prime[j]=false;
      }
    }
  }
  for(int i=2;i<SMAX;i++){
    if(prime[i])
      primes.pb(i);
  }
}

//u should be less than SMAX*SMAX
void segmentedSieve(lli l,lli u){
  segprime.clear();
  segprime.assign(u-l+1,true);
  segprimes.clear();
  if(l==1) segprime[0]=false;
  for(auto it:primes){
    if(it*it>u) break;
    lli init=(l/it)*it;
    if(init<l) init+=it;
    if(init==it) init+=it;
    while(init<=u){
      if(init>=l) segprime[init-l]=false;
      init+=it;
    }
  }
  for(lli i=l;i<=u;i++){
    if(segprime[i-l]) segprimes.pb(i);
  }
}
int main(){
  fio;
  cin.tie(NULL);
  sieve();
  lli l,u;
  while(cin>>l){
    cin>>u;
    segmentedSieve(l,u);

  }
  return 0;
} 