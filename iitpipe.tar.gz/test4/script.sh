sudo rmmod driver
sudo make
sudo insmod driver.ko
sudo mknod /dev/iitpipe c 243 0
sudo chmod 777 /dev/iitpipe
gcc -o iit1 iitpipe1.c
gcc -o iit0 iitpipe0.c

