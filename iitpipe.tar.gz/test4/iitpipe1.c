#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#define DEVICE "/dev/iitpipe"

int main(){
	int i,fd;
	char ch,read_buff[1000];
	int prevlen=0;
	int currlen=0;
	int ct=0;	
	int fp=fopen("out1.txt","w");
	int clock_opened=0;
	clock_t begin;
	time_t t1;
	int var=0;
	int cttt=0;
	while(1){
		fd=open(DEVICE, O_RDONLY);
		if(fd==-1){
			continue;
		}
		int xx=read(fd,read_buff,sizeof(read_buff));
		//printf("%d\n",xx);
		if(xx!=0 && read_buff[0]!=-1){
			cttt=0;
			if(clock_opened==0){
				time(&t1);
				begin=clock();
				clock_opened=1;
			}
			fprintf(fp,"%.*s",xx,read_buff);
			//printf("%.*s", xx, read_buff);		
		}
		if(xx==-1 || read_buff[0]==-1){
			close(fd);
			break;
		}
		if(xx==0){
			cttt++;
		}
		if(cttt>10000)
			break;
		close(fd);
	}
	clock_t end= clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("Execution time : %lf\n",time_spent);
	time_t t2;
	time(&t2);
	double diff_t = difftime(t2, t1);
	printf("Total running time : %f\n",diff_t);
	return 0;
}
