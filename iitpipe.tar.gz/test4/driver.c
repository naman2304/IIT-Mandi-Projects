#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/semaphore.h>
#include <asm/uaccess.h>
#include <linux/moduleparam.h>
#include <linux/delay.h>

//(1) Create a structure for our fake device
#define MAX  1000
#define DELAY 0
struct fake_device {
	char data[MAX];
	struct semaphore sem;
	struct semaphore sem2;
	unsigned int curr;
} virtual_device;

char bufSourceData[100];

struct timer_list my_timer;
bool empty=true;
int dist,ret1,ret2,i;
int rptr=0;
int wptr=0;
int flag=1;
//(2) To later register our device we need a cdev object and some other variables
struct cdev *mcdev; //m stands 'my'
int major_number; //will store our major number- extracted from dev_t using macro - mknod /director/file c major minor
int ret;  //will be used to hold return values of functions; this is because the kernel stack is very small
//so declaring variables all over the pass in our module functions eats up the stack very fast 
dev_t dev_num;  //will hold major number that kernel gives us
//name--> appears in /proc/devices
#define DEVICE_NAME "iitpipe"
bool dowriteonly=false;

//(7)called on device_file open
// inode reference to the file on disk
// and contains information about that file
// struct file is represents an abstract open file
int device_open(struct inode *inode, struct file *filp){
	/*if(filp->f_mode==FMODE_READ){
	  printk(KERN_ALERT "read only\n");
	  }else if(filp->f_mode==FMODE_WRITE){
	  printk(KERN_ALERT "write only\n");
	  }*/
	/*if(dowriteonly==true && (filp->f_flags & O_ACCMODE)==O_RDONLY){
	  return -1;
	  }*/
	if(down_interruptible(&virtual_device.sem) != 0){
		printk(KERN_ALERT "mycode: could not lock device during open");
		return -1;
	}
	printk(KERN_INFO "mycode: opened device");
	return 0;
}

void device_write_Util(unsigned long bufCount){
	return;
}
//(8) called when user wants to get information from the device
ssize_t device_read(struct file* filp, char* bufStoreData, size_t bufCount, loff_t* curOffset){
	//take data from kernel space(device) to user space (processs)
	//copy_to_user (destination, source,sizeToTransfer)
	/*if(dowriteonly==true){
	  return -1;
	  }*/
	if(rptr==wptr){
		//dowriteonly=true;
		printk(KERN_INFO "Case 1\n");
		ret=0;
	}else if(rptr<wptr){
		if(bufCount==wptr-rptr){
			printk(KERN_INFO "Case 2a\n");
			copy_to_user(bufStoreData,virtual_device.data+rptr,bufCount);
			ret=bufCount;
			rptr=wptr;
		}else if(bufCount<wptr-rptr){
			printk(KERN_INFO "Case 2b\n");
			copy_to_user(bufStoreData,virtual_device.data+rptr,bufCount);
			ret=bufCount;
			rptr=rptr+bufCount;
		}else{
			printk(KERN_INFO "Case 2c\n");
			copy_to_user(bufStoreData,virtual_device.data+rptr,wptr-rptr);
			ret=wptr-rptr;
			rptr=wptr;
		}
	}else{
		dist=MAX-rptr+wptr;
		if(dist==bufCount){
			printk(KERN_INFO "Case 3a\n");
			copy_to_user(bufStoreData,virtual_device.data+rptr,MAX-rptr);
			copy_to_user(bufStoreData+MAX-rptr,virtual_device.data,wptr);
			ret=MAX+wptr-rptr;
			rptr=wptr;
		}else if(bufCount<dist){
			if(bufCount==MAX-rptr){
				printk(KERN_INFO "Case 3 b b\n");
				copy_to_user(bufStoreData,virtual_device.data+rptr,bufCount);
				ret=bufCount;
				rptr=0;
			}else if(bufCount<MAX-rptr){
				printk(KERN_INFO "Case 3 b b\n");
				copy_to_user(bufStoreData,virtual_device.data+rptr,bufCount);
				ret=bufCount;
				rptr=rptr+bufCount;
			}else{
				printk(KERN_INFO "Case 3 b c\n");
				copy_to_user(bufStoreData,virtual_device.data+rptr,MAX-rptr);
				copy_to_user(bufStoreData+MAX-rptr,virtual_device.data,bufCount-(MAX-rptr));
				ret=bufCount;
				rptr=bufCount-(MAX-rptr);
			}
		}else{
			printk(KERN_INFO "Case 3 c\n");
			copy_to_user(bufStoreData,virtual_device.data+rptr,MAX-rptr);
			copy_to_user(bufStoreData+MAX-rptr,virtual_device.data,wptr);
			ret=MAX-rptr+wptr;
			rptr=wptr;
		}
	}
	if(flag==-1){
		return -1;
	}
	printk(KERN_INFO "R %d %d\n",rptr,wptr);
	return ret;
}
//(9) called when user wants to send information to the device
ssize_t device_write(struct file* filp, const char* bufSourceData,size_t bufCount, loff_t* curOffset){
	//send data from user to kernel
	//copy_from_user (dest, source, count)
	if(bufCount==1){
		flag=-1;
		virtual_device.data[wptr]=0;
	}
	msleep(DELAY);
	if(bufCount==0){
		ret=0;
	}
	if(bufCount>MAX-1){
		return -1;
	}else{
		if(wptr==rptr){
freetowrite:
			if(wptr!=rptr){
				return -1;
			}
			if(bufCount==MAX-wptr){
				printk(KERN_INFO "Case 1a\n");
				ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
				wptr=0;
			}else if(bufCount<MAX-wptr){
				printk(KERN_INFO "Case 1b\n");
				ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
				wptr=wptr+bufCount;
			}else{
				printk(KERN_INFO "Case 1c\n");
				ret1=copy_from_user(virtual_device.data+wptr,bufSourceData,MAX-wptr);
				ret2=copy_from_user(virtual_device.data,bufSourceData+MAX-wptr,bufCount-(MAX-wptr));
				wptr=bufCount-(MAX-wptr);
				ret= ret1+ret2;
			}
		}else if(wptr<rptr){
			dist=rptr-wptr-1;
			if(bufCount==dist){
				printk(KERN_INFO "Case 2a\n");
				ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
				wptr=rptr-1;
			}else if(bufCount<dist){
				printk(KERN_INFO "Case 2b\n");
				ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
				wptr=wptr+bufCount;
			}else{
				printk(KERN_INFO "Case 2c\n");
				up(&virtual_device.sem);
				while(rptr!=wptr){	
					printk(KERN_INFO "%d %d\n",rptr,wptr);
				}
				printk(KERN_INFO "back to write\n");
				if(down_interruptible(&virtual_device.sem)!=0){
				}
				goto freetowrite;
			}
		}else{
			dist=MAX-wptr+rptr-1;
			if(dist==bufCount){
				if(bufCount==MAX-wptr){
					printk(KERN_INFO "Case 3 a a\n");
					ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
					wptr=0;
				}else if(bufCount<MAX-wptr){
					printk(KERN_INFO "Case 3 a b\n");
					ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
					wptr=wptr+bufCount;
				}else{
					printk(KERN_INFO "Case 3 a c\n");
					ret1=copy_from_user(virtual_device.data+wptr,bufSourceData,MAX-wptr);
					ret2=copy_from_user(virtual_device.data,bufSourceData+MAX-wptr,bufCount-(MAX-wptr));
					wptr=bufCount-(MAX-wptr);
					ret= ret1+ret2;
				}
			}else if(bufCount<dist){
				if(bufCount==MAX-wptr){
					printk(KERN_INFO "Case 3 b a\n");
					ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
					wptr=0;
				}else if(bufCount<MAX-wptr){
					printk(KERN_INFO "Case 3 b b\n");
					ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
					wptr=wptr+bufCount;
				}else{
					printk(KERN_INFO "Case 3 b c\n");
					ret1=copy_from_user(virtual_device.data+wptr,bufSourceData,MAX-wptr);
					ret2=copy_from_user(virtual_device.data,bufSourceData+MAX-wptr,bufCount-(MAX-wptr));
					wptr=bufCount-(MAX-wptr);
					ret=ret1+ret2;
				}
			}else{
				printk(KERN_INFO "Case 3 c\n");
				up(&virtual_device.sem);
				while(rptr!=wptr){
					printk(KERN_INFO "%d %d\n",rptr,wptr);
				}
				printk(KERN_INFO "back to write2\n");
				if(down_interruptible(&virtual_device.sem)!=0){
				}
				goto freetowrite;
			}
		}
	}
	/*ret=copy_from_user(virtual_device.data+wptr,bufSourceData,bufCount);
	  wptr=wptr+bufCount;*/
	for(i=0;i<MAX;i++){
		printk(KERN_INFO "%d : %c",i,virtual_device.data[i]);
	}
	printk(KERN_INFO "\n");
	printk(KERN_INFO "W %d %d\n",rptr,wptr);
	//dowriteonly=false;
	return ret;
}

ssize_t device_writes(struct file* filp, const char* ttbufSourceData,size_t bufCount, loff_t* curOffset){
	for(i=0;i<bufCount;i++){
		bufSourceData[i]=ttbufSourceData[i];
	}
	//printk(KERN_INFO "\n")
	setup_timer( &my_timer, device_write_Util, bufCount );
	//printk( "Starting timer to fire in %dms (%ld)\n", DELAY,jiffies );
	mod_timer( &my_timer, jiffies + msecs_to_jiffies(DELAY) );
}

//(10) called upon user close
int device_close(struct inode *inode, struct file *filp){

	//by calling up , which is opposite of down for semaphore, we release the mutex that we obtained at device open
	//this has the effect of allowing other process to use the device now
	up(&virtual_device.sem);
	printk(KERN_INFO "mycode: closed device");
	return 0;
}


//HERE
//(6) Tell the kernel which functions to call when user operates on our device file
struct file_operations fops = {
	.owner = THIS_MODULE,  //prevent unloadind of this module when operations are in use
	.open = device_open,  //points to the method to call when opening the device
	.release = device_close, //points to the method to call when closing the device
	.write = device_write,  //points to the method to call when writing to the device
	.read = device_read  //points to the method to call when reading from the device
};


static int driver_entry(void){

	//(3) Register our device with the system: a two step process
	//step(1) use dynamic allocation to assign our device
	//    a major number-- alloc_chrdev_region(dev_t*, uint fminor, uint count, char* name)
	ret = alloc_chrdev_region(&dev_num,0,1,DEVICE_NAME);
	if(ret < 0) { //at time kernel functions return negatives, there is an error
		printk(KERN_ALERT "mycode: failed to allocate a major number");
		return ret; //propagate error
	}
	major_number = MAJOR(dev_num); //extracts the major number and store in our variable (MACRO)
	printk(KERN_INFO "mknod /dev/%s c %d 0",DEVICE_NAME,major_number); //dmesg
	//step(2)
	mcdev = cdev_alloc(); //create our cdev structure, initialized our cdev
	mcdev->ops = &fops;  //struct file_operations
	mcdev->owner = THIS_MODULE; 
	//now that we created cdev, we have to add it to the kernel 
	//int cdev_add(struct cdev* dev, dev_t num, unsigned int count)
	ret = cdev_add(mcdev, dev_num, 1);
	if(ret < 0) {
		printk(KERN_ALERT "mycode: unable to add cdev to kernel");
		return ret;
	}
	//Initialize our semaphore
	sema_init(&virtual_device.sem,1);
	sema_init(&virtual_device.sem2,1);
	return 0; 
}

static void driver_exit(void){
	//unregister everyting in reverse order
	cdev_del(mcdev);
	unregister_chrdev_region(dev_num, 1);
	printk(KERN_ALERT "mycode: unloaded module");
}

module_init(driver_entry);
module_exit(driver_exit);
