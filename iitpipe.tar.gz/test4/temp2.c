#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/semaphore.h>
#include <asm/uaccess.h>
#include <linux/moduleparam.h>

//(1) Create a structure for our fake device
#define MAX 10

struct fake_device {
 char data[MAX];
 struct semaphore sem;
 struct semaphore sem2;
 unsigned int curr;
} virtual_device;
