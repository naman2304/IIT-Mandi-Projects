#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define DEVICE "/dev/iitpipe"

int main(){
	int i,fd,xx;
	char ch,write_buff[70];
	char endd[1];
	int ct=0;
	FILE *fp;
	fp=fopen("temp.txt", "r");
	while(1){
		if(fgets(write_buff,70,fp)==NULL){
			write_buff[0]=EOF;
			//printf("ha %d %s\n",1,write_buff);
			write(fd,write_buff,1);
			close(fd);
			//printf("222 %c",EOF);
			break;
		}
		yoyo:
		fd=open(DEVICE, O_WRONLY);
		if(fd==-1){
			printf("haha\n");
			goto yoyo;
		}
		//printf("%d %s\n",strlen(write_buff),write_buff);
		int pp=write(fd,write_buff,strlen(write_buff));
		if(pp==-1)
			goto yoyo;
		close(fd);
	}
	fclose(fp);
	return 0;
}
