#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define N 10010
#define LN 15

int chainNo,ptr=0;
vvll edge(N);
vl baseArray(N),chainHead(N),chainInd(N),subsize(N),seen(N),depth(N),posInBase(N);
vvl par(LN,vl(N));
vll E;

void dfs(int src,int cdepth){
  seen[src]=1;
  depth[src]=cdepth;
  subsize[src]=1;
  for(auto it:edge[src]){
    if(!seen[it.first]){
      dfs(it.first,cdepth+1);
      subsize[src]+=subsize[it.first];
      par[0][it.first]=src;
    }
  }
}

//Using concept of vertex disjoint paths and not edge disjoint paths
//Hence wt of node 0 is -1
//        X                       X(-1)
//    (3)/ \(7)                  / \
//      X   X        --->    (3)X   X(7)
//         / \(2)                  / \
//     (4)/   \                   /   \
//       X     X              (4)X     X(2)
void HLD(int src,int cst,int prev){
  if(chainHead[chainNo]==-1) chainHead[chainNo]=src;
  chainInd[src]=chainNo;
  posInBase[src]=ptr;
  baseArray[ptr]=cst;
  ptr++;
  int ncost,nsrc=-1;
  for(auto it:edge[src]){
    if(it.first!=prev){
      if(nsrc==-1 || subsize[nsrc]<subsize[it.first]){
        ncost=it.second;
        nsrc=it.first;
      }
    }
  }
  if(nsrc!=-1) HLD(nsrc,ncost,src);
  for(auto it:edge[src]){
    if(it.first!=prev && it.first!=nsrc){
      chainNo++;
      HLD(it.first,it.second,src);
    }
  }
}

int lca(int u, int v){
  if(depth[u]<depth[v]) swap(u,v);
  int k=depth[u]-depth[v];
  for(int i=0;i<LN;i++) if((1<<i)&k) u=par[i][u];
  if(u==v) return u;
  for(int i=LN-1;i>=0;i--) if(par[i][u]!=par[i][v]) {
    u=par[i][u];
    v=par[i][v];
  }
  return par[0][u];
}

//i-indexed tree and 1 indexed A
class SegmentTree{
private:
  vl tree,A;
  map<lli,lli> mp;
  lli n;
  lli left (lli p) { return p<<1; }
  lli right(lli p) { return (p<<1)+1; }

  lli combine(lli x,lli y){
    return max(x,y);
  }

  void build(lli p,lli l,lli r){
    if(l==r){
      tree[p]=A[l];
      mp[l]=p;
    }else{
      build(left(p),l,(l+r)/2);
      build(right(p),(l+r)/2+1,r);
      tree[p]=combine(tree[left(p)],tree[right(p)]);
    }
  }

  lli query(lli p,lli l,lli r,lli i,lli j){
    if(i>r || j<l) return NINF;
    lli mid=(l+r)/2;
    if(l>=i && r<=j) return tree[p];
    if(j<=mid) return query(left(p),l,mid,i,j);
    else if(i>mid) return query(right(p),mid+1,r,i,j);
    lli x=query(left(p),l,mid,i,mid);
    lli y=query(right(p),mid+1,r,mid+1,j);
    return combine(x,y);
  }
  
public:
  SegmentTree(){}
  SegmentTree(const vl &_A){
    A=_A;
    n=(lli)A.size()-1;
    tree.assign(4*n+5,0);
    build(1,1,n);
  }

  lli query(lli i,lli j){
    return query(1,1,n,i,j);
  }

  void update(lli pos,lli val){
    pos=mp[pos];
    tree[pos]=val;
    int fat=pos/2;
    while(fat!=0){
        tree[fat]=combine(tree[left(fat)],tree[right(fat)]);
        fat=fat/2;
    }
  }
};

SegmentTree *S;

int query_up(int u,int v){
  if(u==v) return 0;
  int uchain,vchain=chainInd[v],ans=-1;
  while(1){
    uchain=chainInd[u];
    if(uchain==vchain){
      if(u==v) break;
      ans=max(ans,(int)S->query(posInBase[v]+1,posInBase[u]));
      break;
    }
    ans=max(ans,(int)S->query(posInBase[chainHead[uchain]],posInBase[u]));
    u=chainHead[uchain];
    u=par[0][u];
  }
  return ans;
}

int query(int u,int v){
  int w=lca(u,v);
  int t1=query_up(u,w);
  int t2=query_up(v,w);
  return max(t1,t2);
}

//Change value of ith edge
//Thus, we change the "node" value which is below.
void change(int i,int val){
  int u=E[i].first;
  int v=E[i].second;
  if(depth[u]<depth[v]) S->update(posInBase[v],val);
  else S->update(posInBase[u],val);
}

// Walk up to kth ancestor of u and return the kth ancestor
int walk(int u,int k){
  for(int i=0;i<LN;i++) if((1<<i)&k) u=par[i][u];
    return u;
}

int dist(int u,int v){
  int w=lca(u,v);
  return depth[u]+depth[v]-2*depth[w];
}

int main(){
  fio;
  cin.tie(NULL);
  int t;
  cin>>t;
  while(t--){
    int n;
    cin>>n;
    E.clear();
    for(int i=0;i<n;i++){
      edge[i].clear();
      chainHead[i]=-1;
      seen[i]=0;
      depth[i]=0;
      for(int j=0;j<LN;j++) par[j][i]=-1;
    }
    for(int i=1;i<n;i++){
      int u,v,c;
      cin>>u>>v>>c;
      E.pb(mp(u-1,v-1));
      edge[u-1].pb(mp(v-1,c));
      edge[v-1].pb(mp(u-1,c));
    }
    ptr=0;
    chainNo=0;
    dfs(0,0);
    HLD(0,-1,-1);
    S=new SegmentTree(baseArray);
    for(int k=1;k<LN;k++){
      for(int i=0;i<n;i++){
        if(par[k-1][i]==-1) continue;
        par[k][i]=par[k-1][par[k-1][i]];
      }
    }
    while(1){
      string s;
      cin>>s;
      if(s[0]=='D') break;
      int a,b;
      cin>>a>>b;
      if(s[0]=='Q'){
        cout<<query(a-1,b-1)<<"\n";
      }else{
        change(a-1,b);
      }
    }
  }
  return 0;
} 