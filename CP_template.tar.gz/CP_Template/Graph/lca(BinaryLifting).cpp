#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define SMAX 2000010
#define MAXN 100010
#define MAXLN 22

int n,q;
vvl par(MAXLN,vl(MAXN,-1));
vvl maxi(MAXLN,vl(MAXN));
vvll edge(MAXN);
vl depth(MAXN),seen(MAXN);

void dfs(int src,int currht){
  depth[src]=currht;
  seen[src]=true;
  for(auto it:edge[src]){
    if(!seen[it.first]){
      dfs(it.first,currht+1);
      par[0][it.first]=src;
      maxi[0][it.first]=it.second;
    }
  }
}

int lca(int u, int v){
  if(depth[u]<depth[v]) swap(u,v);
  int k=depth[u]-depth[v];
  for(int i=0;i<MAXLN;i++) if((1<<i)&k) u=par[i][u];
  if(u==v) return u;
  for(int i=MAXLN-1;i>=0;i--) if(par[i][u]!=par[i][v]) {
    u=par[i][u];
    v=par[i][v];
  }
  return par[0][u];
}

// Walk up to kth ancestor of u and return the kth ancestor
int walk(int u,int k){
  for(int i=0;i<MAXLN;i++) if((1<<i)&k) u=par[i][u];
    return u;
}

int dist(int u,int v){
  int w=lca(u,v);
  return depth[u]+depth[v]-2*depth[w];
}

int query(int u, int v){
  lli ans=0;
  if(depth[u]<depth[v]) swap(u,v);
  int k=depth[u]-depth[v];
  for(int i=0;i<MAXLN;i++) if((1<<i)&k){
    ans=max(ans,maxi[i][u]);
    u=par[i][u];
  }
  if(u==v) return ans;
  for(int i=MAXLN-1;i>=0;i--) if(par[i][u]!=par[i][v]) {
    ans=max(ans,maxi[i][u]);
    ans=max(ans,maxi[i][v]);
    u=par[i][u];
    v=par[i][v];
  }
  return max(ans,max(maxi[0][u],maxi[0][v]));
}
int main(){
  fio;
  cin.tie(NULL);
  cin>>n;
  for(int i=2;i<=n;i++){
    int a,b,c;
    cin>>a>>b>>c;
    edge[a-1].pb(mp(b-1,c));
    edge[b-1].pb(mp(a-1,c));
  }
  //Binary Lifting initialisation
  dfs(0,0);
  for(int k=1;k<MAXLN;k++){
    for(int i=0;i<n;i++){
      if(par[k-1][i]==-1) continue;
      par[k][i]=par[k-1][par[k-1][i]];
      maxi[k][i]=max(maxi[k-1][i],maxi[k-1][par[k-1][i]]);
    }
  }
  //Queries : Maximum weight of edge in path from u and v
  cin>>q;
  for(int i=0;i<q;i++){
    int a,b;
    cin>>a>>b;
    --a; --b;
    cout<<query(a,b)<<"\n";
  }
  return 0;
} 