#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12

lli V,E;
stack<lli> myst;
vector<bool> visited(MAX,false);
vector<vector<lli> > edge(MAX);
vector<vector<lli> > revedge(MAX);
//Prints strongly connected components in a directed graph
//vertices are 1 indexed
void dfs(lli src){
	visited[src]=true;
	for(auto it:edge[src]){
		if(!visited[it])
			dfs(it);
	}
	myst.push(src);
}
void reversegraph(){
	for(int i=1;i<=V;i++){
		for(auto it:edge[i]){
			revedge[it].pb(i);
		}
	}
}
void rev_dfs(lli src){
	visited[src]=true;
	cout<<src<<" ";
	for(auto it:revedge[src]){
		if(!visited[it])
			rev_dfs(it);
	}
}
void kosaraju(){
	for(int i=1;i<=V;i++){
		if(!visited[i]){
			dfs(i);
		}
	}
	reversegraph();
	for(int i=1;i<=V;i++) visited[i]=false;
	while(!myst.empty()){
		lli src=myst.top();
		myst.pop();
		if(!visited[src]){
			rev_dfs(src);
			cout<<endl;
		}
	}
}
int main(){
	cin>>V>>E;
	for(int i=1;i<=E;i++){
		lli tmp1,tmp2;
		cin>>tmp1>>tmp2;
		edge[tmp1].pb(tmp2);
	}
	kosaraju();
	return 0;
}