#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12

typedef struct Point{
	double x,y;
}Point;

vector<Point> hull;
vector<Point> points(MAX);
stack<Point> myst;
int n;
Point p0;

lli orientation(Point p1,Point p2,Point p3){
	double val=(p2.y-p1.y)*(p3.x-p2.x)-(p2.x-p1.x)*(p3.y-p2.y);
	if(val==0) return 0; //Collinear
	return val>0?1:2; //1:clockwise 2:anticlockwise
}

bool onSegment(Point p,Point q,Point r){
	if(q.x<=max(p.x,r.x) && q.x>=min(p.x,r.x) && q.y<=max(p.y,r.y) && q.y>=min(p.y,r.y))
		return true;
	return false;		
}

//Return true if line segment p1q1 intersect line segment p2q2
bool doIntersect(Point p1,Point q1,Point p2,Point q2){
	lli o1=orientation(p1,q1,p2);
	lli o2=orientation(p1,q1,q2);
	lli o3=orientation(p2,q2,p1);
	lli o4=orientation(p2,q2,q1);

	//General case
	if(o1!=o2 && o3!=o4) return true;

	//Special case
	if(o1==0 && onSegment(p1,p2,q1)) return true;
	if(o2==0 && onSegment(p1,q2,q1)) return true;
	if(o3==0 && onSegment(p2,p1,q2)) return true;
	if(o4==0 && onSegment(p2,q1,q2)) return true;

	return false;
}

//Assumption : collinear points not present
void jarvisConvexHull(){
	if(n<3) return;
	lli l=0;
	for(lli i=1;i<n;i++)
		if(points[i].x<points[l].x)
			l=i;
	lli p=l,q;
	do{
		hull.pb(points[p]);
		q=(p+1)%n;
		for(lli i=0;i<n;i++){
			if(orientation(points[p],points[i],points[q])==2)
				q=i;
		}
		p=q;
	}while(p!=l);
}
void printJarvisConvexHull(){
	for(lli i=0;i<hull.size();i++){
		cout<<"( "<<hull[i].x<<" , "<<hull[i].y<<" )\n";
	}
}

void swap(Point &p1,Point &p2){
	Point q=p1;
	p1=p2;
	p2=q;
}
double distSq(Point p1,Point p2){
	return (p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y);
}
bool compare(const Point &p1,const Point &p2){
	lli o=orientation(p0,p1,p2);
	if(o==1) return false;
	else if(o==2) return true;
	else{
		return distSq(p0,p1)>=distSq(p0,p2)?false:true;
	}
}
Point nextToTop(){
	Point p=myst.top();
	myst.pop();
	Point q=myst.top();
	myst.push(p);
	return q;
}
void grahamConvexHull(){
	if(n<3) return;
	lli ymin=0;
	for(lli i=1;i<n;i++){
		if(points[i].y<points[ymin].y || (points[i].y==points[ymin].y && points[i].x<points[ymin].x))
			ymin=i;
	}
	swap(points[0],points[ymin]);
	p0=points[0];
	sort(points.begin()+1,points.begin()+n,compare);
	lli m=1;
	for(int i=1;i<n;i++){
		while(i<n-1 && orientation(p0,points[i],points[i+1])==0)
			i++;
		points[m]=points[i];
		m++;
	}
	if(m<3) return;
	myst.push(points[0]);
	myst.push(points[1]);
	myst.push(points[2]);
	for(int i=3;i<m;i++){
		while(orientation(nextToTop(),myst.top(),points[i])!=2)
			myst.pop();
		myst.push(points[i]);
	}
}
void printGrahamConvexHull(){
	while(!myst.empty()){
		Point temp=myst.top();
		cout<<"( "<<temp.x<<" , "<<temp.y<<" )\n";
		myst.pop();
	}
}
int main(){
	points[0]={0, 3};
	points[1]={2, 2};
	points[2]={1, 1};
	points[3]={2, 1};
    points[4]={3, 0};
    points[5]={0, 0};
    points[6]={3, 3};
    n=7;
    grahamConvexHull();
    printGrahamConvexHull();
	return 0;
}