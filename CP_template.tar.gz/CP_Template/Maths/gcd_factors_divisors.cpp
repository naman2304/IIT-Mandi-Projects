#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-9
#define INF LONG_MAX
#define NINF LONG_MIN
#define SMAX 100000
  
vB prime(SMAX,true);
vl primes,segprimes;
vB segprime;

lli gcd(lli a,lli b) { return b==0?a:gcd(b,a%b); }
lli lcm(lli a,lli b) { return a*(b/gcd(a,b)); }

//Largest integer which when divides A[0],A[1],..,A[n-1] leaves the same remainder
//Sort A : answer is gcd(A[1]-A[0],A[2]-A[0], .. , A[n-1]-A[0])

//Zeckendorf's theorem :
//Every +ve integer can be expressed uniquely as sum of 1 or more distinct Fib nums
//in such a way that the sum does not include any two consecutive Fibonacci numbers
//GREEDY algo

void sieve(){
  prime[0]=prime[1]=false;
  for(int i=2;i*i<SMAX;i++){
    if(prime[i]){
      for(int j=i*i;j<SMAX;j+=i){
        prime[j]=false;
      }
    }
  }
  for(int i=2;i<SMAX;i++){
    if(prime[i])
      primes.pb(i);
  }
}

//Counts number of prime factor
lli numPF(lli N){
  lli ans=0,PF_idx=0,PF=primes[PF_idx];
  while(PF*PF<=N){
    while(N%PF==0){
      N=N/PF;
      ans++;
    }
    PF=primes[++PF_idx];
  }
  if(N!=1) ans++;
  return ans;
}

//Returns list of all prime factors (duplicates too)
vl primeFactors(lli N){
  vl factors;
  lli PF_idx=0,PF=primes[PF_idx];
  while(PF*PF<=N){
    while(N%PF==0){
      N=N/PF;
      factors.pb(PF);
    }
    PF=primes[++PF_idx];
  }
  if(N!=1) factors.pb(N);
  return factors;
}

//Returns number of divisors of a N
lli numDiv(lli N){
  lli PF_idx=0,PF=primes[PF_idx];
  lli ans=1;
  while(PF*PF<=N){
    int power=0;
    while(N%PF==0){
      N=N/PF;
      power++;
    }
    ans=ans*(power+1);
    PF=primes[++PF_idx];
  }
  if(N!=1) ans=ans*2;
  return ans;
}

//Returns sum of divisors of a N
lli sumDiv(lli N){
  lli PF_idx=0,PF=primes[PF_idx];
  lli ans=1;
  while(PF*PF<=N){
    int power=0;
    while(N%PF==0){
      N=N/PF;
      power++;
    }
    ans*=((lli)pow(PF,power+1)-1)/(PF-1);
    PF=primes[++PF_idx];
  }
  if(N!=1) ans*=((lli)pow((double)N,2.0)-1)/(N-1);
  return ans;
}

//Returns list of all divisors of number including 1 and the number itself
vl divisors(lli N){
  vl divi;
  for(int i=1;i*i<=N;i++){
    if(N%i==0){
      divi.pb(i);
      if(i*i!=N) divi.pb(N/i);
    }
  }
  return divi;
}

//Euler Totient Function
//Counts the number of +ve integer <N that are relatively prime to N i.e.gcd(x,N)=1
//Properties : E(mn)=E(m)E(n)
lli EulerPhi(lli N){
  lli PF_idx=0,PF=primes[PF_idx];
  lli ans=N;
  while(PF*PF<=N){
    if(N%PF==0) ans-=ans/PF;
    while(N%PF==0){
      N=N/PF;
    }
    PF=primes[++PF_idx];
  }
  if(N!=1) ans-=ans/N;
  return ans;
}

//Power of p in prime factorisation of n! (factorial)
lli getpow(lli p,lli n){
  lli res=0,ind=1;
  while(1){
    if(pow(p,ind)>n) break;
    res+=n/pow(p,ind);
    ind++;
  }
  return res;
}

int main(){
  fio;
  cin.tie(NULL);
  sieve();
  return 0;
} 