#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define lD long double
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vB vector<bool>
#define vC vector<char>
#define vlD vector<lD>
#define vvC vector<vC>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 500005
#define EPS 1e-4
#define NINF LONG_MIN
#define INF LONG_MAX  

//i-indexed tree and 1 indexed A
class FenwickTree{
private:
  vl tree;
  
public:
  FenwickTree(int n){
    tree.assign(n+1,0);
  }

  lli LSOne(lli a){
    return a & (-a);
  }
  lli query(lli b){
    lli sum=0;
    for(;b;b-=LSOne(b)){
      sum+=tree[b];
    }
    return sum;
  }
  lli query(lli a,lli b){
    return query(b)-(a==1?0:query(a-1));
  }

  //adjusts value of pos'th element by val (val can be +ve/inc or -ve/dec)
  void update(lli pos,lli val){
    for(;pos<(int)tree.size();pos+=LSOne(pos)){
      tree[pos]+=val;
    }
  }
};
int main(){
  int n,m;
  cin>>n>>m;
  vl A(n+1);
  for(int i=1;i<=n;i++) cin>>A[i];
  FenwickTree F(n);
  for(int i=1;i<=n;i++){
    F.update(i,A[i]);
  }
  for(int i=1;i<=m;i++){
    lli l,r;
    cin>>l>>r;
    cout<<F.query(l,r)<<"\n";
  }
  return 0;
}