#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define fio ios_base::sync_with_stdio(0)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vi >
#define vii vector<ii >
#define vvii vector<vii >
#define ll pair<lli,lli>
#define vl vector<lli>
#define vvl vector<vl >
#define vll vector<ll >
#define vvll vector<vll >
#define M_PI 3.14159265358979323846
#define MOD 1000000007
#define MAX 200005
#define EPS 1e-12
#define NINF LONG_MIN
#define INF LONG_MAX
//cout<<"Case #"<<tc<<": ";

int main(){
    lli t,tc=1;
    cin>>t;
    while(t--){
        lli n,m;
        cin>>n>>m;
        vvl dp(n+1,vl(m+1,0));
        string s1,s2;
        cin>>s1>>s2;
        lli fans=0;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(s1[i-1]==s2[j-1]){
                    dp[i][j]=1+dp[i-1][j-1];
                }else{
                    dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
                }
                fans=max(fans,dp[i][j]);
            }
        }
        cout<<fans<<"\n";
    }
    return 0;
}