#include <bits/stdc++.h>
using namespace std;
#define MAX 1001

vector<int> ID(MAX),cnt(MAX);
vector<string> attribute(MAX);
int maxID;

int main(){
	ifstream fin;
	ofstream fout;
	fin.open("database.txt");
	fout.open("query.txt");
	fout<<"graph=TinkerGraph.open();\n";
	fout<<"g=graph.traversal();\n";
	int temp,temp2;
	string s,s2;
	while(fin>>temp){
		maxID=max(maxID,temp);
		ID[temp]=temp;
		fin>>s;
		if(s=="a"){
			getline(fin,s2);
			s2[1]='[';
			s2[s2.length()-1]=']';
			fout<<"v"+to_string(temp)+"=graph.addVertex();\n";
			fout<<"v"+to_string(temp)+".property(\"id\",\"" + to_string(temp) + "\");\n";
			fout<<"v"+to_string(temp)+".property(\"attribute\"," + attribute[temp] + ");\n";
		}else if(s=="c"){
			fin>>temp2;
			cnt[temp]=temp2;
		}else if(s=="ap"){
			fin>>temp2;
			fout<<"g.V().has(\"id\",\""+to_string(temp2)+"\").outE(\"parent\").where(otherV().has(\"id\",\""+to_string(temp)+"\")).drop();\n";
			fout<<"v"+to_string(temp2)+".addEdge(\"parent\",v"+to_string(temp)+");\n";
			//cout<<temp2<<"\n";
		}else if(s=="ac"){
			fin>>temp2;
			fout<<"g.V().has(\"id\",\""+to_string(temp)+"\").outE(\"parent\").where(otherV().has(\"id\",\""+to_string(temp2)+"\")).drop();\n";
			fout<<"v"+to_string(temp)+".addEdge(\"parent\",v"+to_string(temp2)+");\n";
		}else if(s=="sc"){
			fin>>temp2;
			fout<<"g.V().has(\"id\",\"" + to_string(temp) + "\").outE(\"parent\").drop();\n";
			fout<<"v"+to_string(temp)+".addEdge(\"parent\",v"+to_string(temp2)+");\n";
		}else{
			cout<<"Error!\n";
			fin.close();
			return 0;
		}
	}
	for(int i=0;i<maxID+1;i++){
		fout<<"v"+to_string(i)+".property(\"count\"," + to_string(cnt[i]) + ");\n";
	}
	fin.close();
	fout.close();
	return 0;
}